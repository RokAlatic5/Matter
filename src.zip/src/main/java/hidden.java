public class hidden {
    final static String token = "OTU1NzQ3MTE4MTAwOTE4MzIy.YjmK3Q.6jWWJ-WUmd_zXbSWjqiM5AMw_Ww";
    final static String url = "jdbc:mysql://sql11.freemysqlhosting.net:3306/sql11482165";
    final static String username = "sql11482165";
    final static String password = "s1eg5uJkNA";
}
